# FUSBA probe: how does the runtime split an input file into records for the generic program (RECORD VARYING 1-4000)?
# Mode C, file-1 key never matches, input length 4000: output 1 = every file-2 record exactly as read (mock: 4,000 B each).
param([String]$File = 'E:\AMT_Work\MockTest\FUSBA_GN\D2\input\COMPLET', [String]$File1 = '', [String]$Binaries = 'E:\AMT_Work\Rebuild177a-spike\AFBUS_2200COBOL\Binaries\Programs')
$ErrorActionPreference = 'Continue'
$mt = 'E:\Repos\SsgTrial\Conversion\Pipeline\MockTest'
. "$mt\MockFc.ps1"
$tmp = 'E:\AMT_Work\MockTest\FUSBA_GN\_probe'
New-Item -ItemType Directory -Force $tmp | Out-Null
$latin1 = [System.Text.Encoding]::GetEncoding('iso-8859-1')
$parm = @(('IN' + 'FUSIN1'.PadRight(30) + '04000'), ('IN' + 'FUSIN2'.PadRight(30) + '04000'), ('OU' + 'FUSOUT1'.PadRight(30) + '00080'), ('OU' + 'FUSOUT2'.PadRight(30) + '04000'), 'MDC', 'K10000100001', 'K20000100001')
[IO.File]::WriteAllLines("$tmp\parm", [String[]]($parm | ForEach-Object { $_.PadRight(80) }), $latin1)
[IO.File]::WriteAllText("$tmp\empty", '', $latin1)
if (-not $File1) { $File1 = "$tmp\empty" }
try {
  Start-MockFc
  $r = & "$mt\Run-ProgramCase.ps1" -Case FUSBA_PROBE -Dll ASSURFED_UTILIT_FUSBA_GN.dll -Inputs @{ SGSPARM = "$tmp\parm"; FUSIN1 = $File1; FUSIN2 = $File } -KeepOutputAs FUSOUT1 -KeepOutputTo "$tmp\out1" -Binaries $Binaries
} finally { try { Stop-MockFc } catch { } }
$src = @([IO.File]::ReadAllLines($File, $latin1))
$got = @([IO.File]::ReadAllLines("$tmp\out1", $latin1) | ForEach-Object { $_.TrimEnd() })
'file: {0} lines, {1:N0} B; program read {2} records  [{3} {4}]' -f $src.Count, (Get-Item $File).Length, $got.Count, $r.Result, $r.Detail
for ($i = 0; $i -lt [Math]::Min(6, $got.Count); $i++) {
  $g = $got[$i]
  $first = [Array]::IndexOf($src, ($src | Where-Object { $g.StartsWith($_.TrimEnd()) -or $_.TrimEnd().StartsWith($g) } | Select-Object -First 1))
  '  rec {0}: {1,5} chars, starts like source line {2}' -f $i, $g.Length, $first
}
