# FUSBA probe: the D2 case's data with its own parameters (mode D) and with only the mode changed (C, 2 outputs).
param([String]$Binaries = 'E:\AMT_Work\Rebuild177a-spike\AFBUS_2200COBOL\Binaries\Programs')
$ErrorActionPreference = 'Continue'
$mt = 'E:\Repos\SsgTrial\Conversion\Pipeline\MockTest'
. "$mt\MockFc.ps1"
. 'E:\Repos\SsgTrial\_scratch\spike-fusba\check\FusbaModel.ps1'
$tmp = 'E:\AMT_Work\MockTest\FUSBA_GN\_probe'
$d = 'E:\AMT_Work\MockTest\FUSBA_GN\D2\input'
$latin1 = [System.Text.Encoding]::GetEncoding('iso-8859-1')
$base = @(('IN' + 'FUSIN1'.PadRight(30) + '00136'), ('IN' + 'FUSIN2'.PadRight(30) + '00136'), ('OU' + 'FUSOUT1'.PadRight(30) + '00136'))
$keys = @('K10001200006', 'K20001200006')
$variants = [ordered]@{ D = $base + 'MDD' + $keys; C = $base + ('OU' + 'FUSOUT2'.PadRight(30) + '00136') + 'MDC' + $keys }
foreach ($v in $variants.Keys) {
  [IO.File]::WriteAllLines("$tmp\parm$v", [String[]]($variants[$v] | ForEach-Object { $_.PadRight(80) }), $latin1)
  $m = Invoke-FusbaModel (Read-FusbaParm $variants[$v]) @("$d\CLE", "$d\COMPLET") @($(if ($v -eq 'C') { "$tmp\m1", "$tmp\m2" } else { "$tmp\m1" }))
  foreach ($f in 'o1', 'o2') { Remove-Item "$tmp\$f" -ErrorAction SilentlyContinue }
  try {
    Start-MockFc
    $null = & "$mt\Run-ProgramCase.ps1" -Case "FUSBA_PROBE_$v" -Dll ASSURFED_UTILIT_FUSBA_GN.dll -Inputs @{ SGSPARM = "$tmp\parm$v"; FUSIN1 = "$d\CLE"; FUSIN2 = "$d\COMPLET" } -KeepOutputAs FUSOUT1 -KeepOutputTo "$tmp\o1" -Binaries $Binaries
    if ($v -eq 'C') { Copy-Item 'E:\AMT_Work\MockTest\Extracts\FUSOUT2.DAT' "$tmp\o2" -ErrorAction SilentlyContinue }
  } finally { try { Stop-MockFc } catch { } }
  $n1 = if (Test-Path "$tmp\o1") { @(Get-Content "$tmp\o1").Count } else { -1 }
  $n2 = if (Test-Path "$tmp\o2") { @(Get-Content "$tmp\o2").Count } else { '-' }
  'mode {0}: program out1 {1} out2 {2}; model {3}' -f $v, $n1, $n2, ($m.Written -join '/')
}
