# BABA diagnosis 5: is it "record 1 matches"? (a) E19 data, value = record 1's key; (b) E1 data without record 1.
$ErrorActionPreference = 'Continue'
$mt = 'E:\Repos\SsgTrial\Conversion\Pipeline\MockTest'
. "$mt\MockFc.ps1"
. 'E:\Repos\SsgTrial\_scratch\spike-baba\check\BabaModel.ps1'
$tmp = 'E:\AMT_Work\MockTest\BABA_GN\_probe'
$latin1 = [System.Text.Encoding]::GetEncoding('iso-8859-1')
function Run([String]$label, [String[]]$parm, [String]$in) {
  [IO.File]::WriteAllLines("$tmp\pr", [String[]]$parm, $latin1)
  $m = Invoke-BabaModel (Read-BabaParm $parm) $in @("$tmp\mr")
  try {
    Start-MockFc
    $null = & "$mt\Run-ProgramCase.ps1" -Case BABA_PROBE -Dll ASSURFED_UTILIT_BABA_GN.dll -Inputs @{ SGSPARM = "$tmp\pr"; BABIN = $in } -ExpectedName BABOUT1 -ExpectedFile $in -KeepOutputAs BABOUT1 -KeepOutputTo "$tmp\or" -Binaries 'E:\AMT_Work\Rebuild177a-spike\AFBUS_2200COBOL\Binaries\Programs'
  } finally { try { Stop-MockFc } catch { } }
  $k = if (Test-Path "$tmp\or") { @(Get-Content "$tmp\or").Count } else { -1 }
  Remove-Item "$tmp\or" -ErrorAction SilentlyContinue
  '{0,-44} program kept {1}, model kept {2}' -f $label, $k, $m.Written[0]
}
$e19 = Get-Content 'E:\AMT_Work\MockTest\BABA_GN\_mock\E19.parm'
$in19 = 'E:\AMT_Work\MockTest\BABA_GN\E19\input\IRESMENS'
$k1 = (Get-Content $in19 -TotalCount 1).Substring(218, 12)
$r = @()
$r += Run "E19 data, one set = record 1 key [$k1]" (@($e19 | Where-Object { -not $_.StartsWith('RQ') }) + "RQ00012$k1") $in19
$e1 = Get-Content 'E:\AMT_Work\MockTest\BABA_GN\_mock\E1.parm'
$in1 = Get-Content 'E:\AMT_Work\MockTest\BABA_GN\E1\input\I001MSG054'
[IO.File]::WriteAllText("$tmp\e1-no1", (($in1 | Select-Object -Skip 1) -join "`r`n") + "`r`n", $latin1)
$r += Run 'E1 data without record 1' $e1 "$tmp\e1-no1"
$r | Set-Content "$tmp\rec1.txt"
