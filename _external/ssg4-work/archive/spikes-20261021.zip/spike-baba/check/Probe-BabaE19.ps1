# BABA diagnosis 4: E19's own parameter file cut to N value sets; how many records go to output 1 (not excluded)?
$ErrorActionPreference = 'Continue'
$mt = 'E:\Repos\SsgTrial\Conversion\Pipeline\MockTest'
. "$mt\MockFc.ps1"
. 'E:\Repos\SsgTrial\_scratch\spike-baba\check\BabaModel.ps1'
$tmp = 'E:\AMT_Work\MockTest\BABA_GN\_probe'
$latin1 = [System.Text.Encoding]::GetEncoding('iso-8859-1')
$all = Get-Content 'E:\AMT_Work\MockTest\BABA_GN\_mock\E19.parm'
$in = 'E:\AMT_Work\MockTest\BABA_GN\E19\input\IRESMENS'
$results = foreach ($n in 1, 2, 5, 19) {
  $parm = @($all | Where-Object { -not $_.StartsWith('RQ') }) + @($all | Where-Object { $_.StartsWith('RQ') } | Select-Object -First $n)
  [IO.File]::WriteAllLines("$tmp\p19", [String[]]$parm, $latin1)
  $p = Read-BabaParm $parm
  $m = Invoke-BabaModel $p $in @("$tmp\m19")
  try {
    Start-MockFc
    $null = & "$mt\Run-ProgramCase.ps1" -Case BABA_PROBE -Dll ASSURFED_UTILIT_BABA_GN.dll -Inputs @{ SGSPARM = "$tmp\p19"; BABIN = $in } -ExpectedName BABOUT1 -ExpectedFile $in -KeepOutputAs BABOUT1 -KeepOutputTo "$tmp\o19" -Binaries 'E:\AMT_Work\Rebuild177a-spike\AFBUS_2200COBOL\Binaries\Programs'
  } finally { try { Stop-MockFc } catch { } }
  $k = if (Test-Path "$tmp\o19") { @(Get-Content "$tmp\o19").Count } else { -1 }
  Remove-Item "$tmp\o19" -ErrorAction SilentlyContinue
  '{0,2} value sets: program kept {1}, model kept {2}' -f $n, $k, $m.Written[0]
}
$results | Set-Content "$tmp\sets19.txt"
