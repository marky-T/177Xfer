# BABA diagnosis 2: does the number/order of value sets change matching? Mode R, key pos 1 len 8.
$ErrorActionPreference = 'Stop'
$mt = 'E:\Repos\SsgTrial\Conversion\Pipeline\MockTest'
. "$mt\MockFc.ps1"
$tmp = 'E:\AMT_Work\MockTest\BABA_GN\_probe'
New-Item -ItemType Directory -Force $tmp | Out-Null
$latin1 = [System.Text.Encoding]::GetEncoding('iso-8859-1')
$recs = 1..6 | ForEach-Object { if ($_ % 2) { 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcd' } else { 'zyxwvutsrqponmlkjihgfedcba9876543210ZYXW' } }
[IO.File]::WriteAllText("$tmp\in", ($recs -join "`r`n") + "`r`n", $latin1)
$head = @('IN' + 'BABIN'.PadRight(30) + '00040', 'OU' + 'BABOUT1'.PadRight(30) + '00040', 'OU' + 'BABOUT2'.PadRight(30) + '00040', 'MDR  N', 'KF0000100008')
$variants = [ordered]@{
  'one set ABCDEFGH'           = @('RQ00008ABCDEFGH')
  'dummy then ABCDEFGH'        = @('RQ00008QQQQQQQQ', 'RQ00008ABCDEFGH')
  'ABCDEFGH then dummy'        = @('RQ00008ABCDEFGH', 'RQ00008QQQQQQQQ')
  'one set, value padded to 40' = @('RQ00008' + 'ABCDEFGH'.PadRight(40))
}
try {
  foreach ($k in $variants.Keys) {
    [IO.File]::WriteAllLines("$tmp\p", [String[]]($head + $variants[$k]), $latin1)
    Start-MockFc
    $null = & "$mt\Run-ProgramCase.ps1" -Case BABA_PROBE -Dll ASSURFED_UTILIT_BABA_GN.dll -Inputs @{ SGSPARM = "$tmp\p"; BABIN = "$tmp\in" } -ExpectedName BABOUT1 -ExpectedFile "$tmp\in" -KeepOutputAs BABOUT1 -KeepOutputTo "$tmp\o1" -Binaries 'E:\AMT_Work\Rebuild177a-spike\AFBUS_2200COBOL\Binaries\Programs'
    Stop-MockFc
    $n = if (Test-Path "$tmp\o1") { @(Get-Content "$tmp\o1").Count } else { -1 }
    Remove-Item "$tmp\o1" -ErrorAction SilentlyContinue
    '{0,-30} -> matched {1} of 3' -f $k, $n
  }
} finally { Stop-MockFc }
