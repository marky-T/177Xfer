# BABA diagnosis: which key positions/lengths does the generic DLL match? Mode R, one value = record 1's key.
$ErrorActionPreference = 'Stop'
$mt = 'E:\Repos\SsgTrial\Conversion\Pipeline\MockTest'
. "$mt\MockFc.ps1"
$tmp = 'E:\AMT_Work\MockTest\BABA_GN\_probe'
New-Item -ItemType Directory -Force $tmp | Out-Null
$latin1 = [System.Text.Encoding]::GetEncoding('iso-8859-1')
$recs = 1..6 | ForEach-Object { if ($_ % 2) { 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcd' } else { 'zyxwvutsrqponmlkjihgfedcba9876543210ZYXW' } }
[IO.File]::WriteAllText("$tmp\in", ($recs -join "`r`n") + "`r`n", $latin1)
$variants = @(@(1, 8), @(1, 12), @(1, 5), @(2, 8), @(9, 8), @(20, 5), @(20, 12), @(1, 16))
try {
  foreach ($v in $variants) {
    $val = $recs[0].Substring($v[0] - 1, $v[1])
    $parm = @('IN' + 'BABIN'.PadRight(30) + '00040', 'OU' + 'BABOUT1'.PadRight(30) + '00040', 'OU' + 'BABOUT2'.PadRight(30) + '00040', 'MDR  N', ('KF{0:D5}{1:D5}' -f $v[0], $v[1]), ('RQ{0:D5}' -f $v[1]) + $val)
    [IO.File]::WriteAllLines("$tmp\p", [String[]]$parm, $latin1)
    Start-MockFc
    $r = & "$mt\Run-ProgramCase.ps1" -Case BABA_PROBE -Dll ASSURFED_UTILIT_BABA_GN.dll -Inputs @{ SGSPARM = "$tmp\p"; BABIN = "$tmp\in" } -ExpectedName BABOUT1 -ExpectedFile "$tmp\in" -KeepOutputAs BABOUT1 -KeepOutputTo "$tmp\o1" -Binaries 'E:\AMT_Work\Rebuild177a-spike\AFBUS_2200COBOL\Binaries\Programs'
    Stop-MockFc
    $n = if (Test-Path "$tmp\o1") { @(Get-Content "$tmp\o1").Count } else { -1 }
    Remove-Item "$tmp\o1" -ErrorAction SilentlyContinue
    'key pos {0,2} len {1,2} value [{2}] -> matched {3} of 3 expected' -f $v[0], $v[1], $val, $n
  }
} finally { Stop-MockFc }
