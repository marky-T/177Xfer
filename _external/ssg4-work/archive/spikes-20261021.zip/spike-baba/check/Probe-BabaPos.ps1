# BABA diagnosis 3: does the key's position decide matching? Mode R, 300-byte records, value = record 1's key.
# MockFc's clean-up reports already-exited processes as errors; they must not end the probe.
$ErrorActionPreference = 'Continue'
$mt = 'E:\Repos\SsgTrial\Conversion\Pipeline\MockTest'
. "$mt\MockFc.ps1"
$tmp = 'E:\AMT_Work\MockTest\BABA_GN\_probe'
New-Item -ItemType Directory -Force $tmp | Out-Null
$latin1 = [System.Text.Encoding]::GetEncoding('iso-8859-1')
$a = -join (0..299 | ForEach-Object { [char](65 + ($_ * 7) % 26) })
$b = -join (0..299 | ForEach-Object { [char](97 + ($_ * 5) % 26) })
$recs = 1..6 | ForEach-Object { if ($_ % 2) { $a } else { $b } }
[IO.File]::WriteAllText("$tmp\in", ($recs -join "`r`n") + "`r`n", $latin1)
$results = foreach ($v in @(@(219, 12), @(77, 5), @(150, 8), @(64, 8), @(1, 8))) {
  $val = $a.Substring($v[0] - 1, $v[1])
  $parm = @('IN' + 'BABIN'.PadRight(30) + '00300', 'OU' + 'BABOUT1'.PadRight(30) + '00300', 'OU' + 'BABOUT2'.PadRight(30) + '00300', 'MDR  N', ('KF{0:D5}{1:D5}' -f $v[0], $v[1]), (('RQ{0:D5}' -f $v[1]) + $val))
  [IO.File]::WriteAllLines("$tmp\p", [String[]]$parm, $latin1)
  try {
    Start-MockFc
    $null = & "$mt\Run-ProgramCase.ps1" -Case BABA_PROBE -Dll ASSURFED_UTILIT_BABA_GN.dll -Inputs @{ SGSPARM = "$tmp\p"; BABIN = "$tmp\in" } -ExpectedName BABOUT1 -ExpectedFile "$tmp\in" -KeepOutputAs BABOUT1 -KeepOutputTo "$tmp\o1" -Binaries 'E:\AMT_Work\Rebuild177a-spike\AFBUS_2200COBOL\Binaries\Programs'
  } finally { try { Stop-MockFc } catch { } }
  $n = if (Test-Path "$tmp\o1") { @(Get-Content "$tmp\o1").Count } else { -1 }
  Remove-Item "$tmp\o1" -ErrorAction SilentlyContinue
  'key pos {0,3} len {1,2} [{2}] -> matched {3} of 3' -f $v[0], $v[1], $val, $n
}
$results | Set-Content "$tmp\pos.txt"
$results
