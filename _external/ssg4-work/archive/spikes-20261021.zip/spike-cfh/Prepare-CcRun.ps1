# Spike: rebuild -GF for 177a, deliver only its DLL, deploy the SSG4 scripts with the hand-off, stage both pilots' inputs and cards.
$ErrorActionPreference = 'Stop'
$out = 'E:\Repos\SsgTrial\_scratch\spike-cfh\prepare-cc.txt'
$x = 'E:\Repos\Federale_InternalRelease\AmtTools\Basepaths\Extracts'
$prog = 'E:\Repos\AMT\Apps\AFBUS_2200COBOL_AMT\Binaries\Programs'
$gen = 'E:\AMT_Work\Apps177\Development\Programs\Assurfed_Utilit_Cfh_Copy_Gf'
$r = @()
$r += 'generated output FDs with VARYING: ' + @(Select-String -Path "$gen\*.Files.cs" -Pattern 'm_Fo\d+\.VariableRecordSize').Count
pwsh -NoProfile -File E:\Repos\SsgTrial\Conversion\Pipeline\MockTest\Rebuild-SetAgainstRuntime.ps1 -Application AFBUS_2200COBOL -OutRoot E:\AMT_Work\Rebuild177a-spike *> E:\Repos\SsgTrial\_scratch\spike-cfh\rebuild3.log
$dll = Get-Item 'E:\AMT_Work\Rebuild177a-spike\AFBUS_2200COBOL\Binaries\Programs\ASSURFED_UTILIT_CFH_COPY_GF.dll'
$r += 'rebuilt: {0:N0} B {1:HH:mm:ss}' -f $dll.Length, $dll.LastWriteTime
Copy-Item $dll.FullName $prog -Force
$r += 'delivered: ' + (Get-Item "$prog\ASSURFED_UTILIT_CFH_COPY_GF.dll").FullName
$r += pwsh -NoProfile -File E:\Repos\SsgTrial\_scratch\ecl-pilot\Deploy-EclPilot.ps1 -Generic
New-Item -ItemType Directory -Force "$x\ASSURFED", "$x\P`$SGS" | Out-Null
Copy-Item E:\AMT_Work\MockTest\AFPH12_L427\input\INASC "$x\ASSURFED\IAFB011FAI" -Force
Copy-Item E:\AMT_Work\MockTest\VIRM01\input\INB "$x\ASSURFED\I006VRM01ATT" -Force
Copy-Item E:\Repos\ssg4-work\sgs-cards\calls\ASSURFED_F999RUN_AFPH12__L427.sgs "$x\P`$SGS\AFPH12" -Force
Copy-Item E:\Repos\ssg4-work\sgs-cards\calls\ASSURFED_F999RUN_VIRM01_CO__L484.sgs "$x\P`$SGS\VIRM01" -Force
foreach ($old in 'IAFB012FAI.DAT', 'I006VRM01ATC', 'I006VRM01ATC.DAT', 'CFHPARM') { if (Test-Path "$x\ASSURFED\$old") { Remove-Item "$x\ASSURFED\$old" -Force; $r += "removed old ASSURFED\$old" } }
$r += Get-ChildItem "$x\ASSURFED", "$x\P`$SGS" -File | ForEach-Object { 'staged {0} {1:N0} B' -f $_.FullName.Substring($x.Length + 1), $_.Length }
$r | Out-File $out
$r
