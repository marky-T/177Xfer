       IDENTIFICATION DIVISION.
      * SSG-4 spike (MT-043): one CFH-COPY for every call. Record shapes,
      * field moves and constants come from the SGSPARM file written by
      * the skeleton hand-off; see _scratch\spike-cfh\spec.md.
       PROGRAM-ID. 'ASSURFED-UTILIT-CFH-COPY-GF'.
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
       SOURCE-COMPUTER. UNIVAC-1100-10.
       OBJECT-COMPUTER. UNIVAC-1100-10.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT PARMF ASSIGN TO DISC SGSPARM.
           SELECT FI1 ASSIGN TO DISC A1.
           SELECT FI2 ASSIGN TO DISC F12VIER01A.
           SELECT FI3 ASSIGN TO DISC FILEIN.
           SELECT FI4 ASSIGN TO DISC FIN.
           SELECT FI5 ASSIGN TO DISC I005T0000810.
           SELECT FI6 ASSIGN TO DISC I006KTMAJ1.
           SELECT FI7 ASSIGN TO DISC I006SANTE.
           SELECT FI8 ASSIGN TO DISC I008CLOA35D.
           SELECT FI9 ASSIGN TO DISC ID50KTMAJ1.
           SELECT FI10 ASSIGN TO DISC ina.
           SELECT FI11 ASSIGN TO DISC INACLOA43.
           SELECT FI12 ASSIGN TO DISC INASC.
           SELECT FI13 ASSIGN TO DISC INB.
           SELECT FI14 ASSIGN TO DISC INP.
           SELECT FI15 ASSIGN TO DISC IPBA07CO99SS.
           SELECT FI16 ASSIGN TO DISC IPBGA02HIDS.
           SELECT FI17 ASSIGN TO DISC IRESSG.
           SELECT FI18 ASSIGN TO DISC IVGR002RES.
           SELECT FI19 ASSIGN TO DISC IVIB151BAB.
           SELECT FI20 ASSIGN TO DISC IVIR002CCH.
           SELECT FI21 ASSIGN TO DISC IVIR002CLO.
           SELECT FI22 ASSIGN TO DISC IVIR002RAD.
           SELECT FO1 ASSIGN TO DISC A2.
           SELECT FO2 ASSIGN TO DISC F006KTMAJ3.
           SELECT FO3 ASSIGN TO DISC FD50KTMAJ3.
           SELECT FO4 ASSIGN TO DISC FILEOUT.
           SELECT FO5 ASSIGN TO DISC FOUT.
           SELECT FO6 ASSIGN TO DISC I005TABSACHG.
           SELECT FO7 ASSIGN TO DISC I008CLOA35E.
           SELECT FO8 ASSIGN TO DISC INC.
           SELECT FO9 ASSIGN TO DISC IPBA07CO99N.
           SELECT FO10 ASSIGN TO DISC IPBGA02HIDT.
           SELECT FO11 ASSIGN TO DISC IVGR002RES2.
           SELECT FO12 ASSIGN TO DISC IVIB151CFH.
           SELECT FO13 ASSIGN TO DISC IVIR002CCHT.
           SELECT FO14 ASSIGN TO DISC IVIR002CLOT.
           SELECT FO15 ASSIGN TO DISC IVIR002RADT.
           SELECT FO16 ASSIGN TO DISC OUT.
           SELECT FO17 ASSIGN TO DISC OUTA.
           SELECT FO18 ASSIGN TO DISC OUTASC.
           SELECT FO19 ASSIGN TO DISC OUTCLOA43.
           SELECT FO20 ASSIGN TO DISC R006SOINSA.
           SELECT FO21 ASSIGN TO DISC REPIN033.
       DATA DIVISION.
       FILE SECTION.
       FD  PARMF
           LABEL RECORD STANDARD.
       01  PARM-REC.
           03  P-TYPE         PIC XX.
           03  P-REST         PIC X(248).
       01  PARM-FILE-REC.
           03  FILLER         PIC XX.
           03  PF-NAME        PIC X(30).
           03  PF-LEN         PIC 9(5).
           03  FILLER         PIC X(213).
       01  PARM-MOVE-REC.
           03  FILLER         PIC XX.
           03  PM-IS          PIC 9(5).
           03  PM-IL          PIC 9(5).
           03  PM-OS          PIC 9(5).
           03  PM-OL          PIC 9(5).
           03  FILLER         PIC X(228).
       01  PARM-FIXE-REC.
           03  FILLER         PIC XX.
           03  PX-OS          PIC 9(5).
           03  PX-LEN         PIC 9(5).
           03  PX-TXT         PIC X(238).
       01  PARM-SKIP-REC.
           03  FILLER         PIC XX.
           03  PS-N           PIC 9(5).
           03  FILLER         PIC X(243).
       FD  FI1
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI1-REC PIC X(4000).
       FD  FI2
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI2-REC PIC X(4000).
       FD  FI3
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI3-REC PIC X(4000).
       FD  FI4
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI4-REC PIC X(4000).
       FD  FI5
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI5-REC PIC X(4000).
       FD  FI6
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI6-REC PIC X(4000).
       FD  FI7
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI7-REC PIC X(4000).
       FD  FI8
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI8-REC PIC X(4000).
       FD  FI9
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI9-REC PIC X(4000).
       FD  FI10
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI10-REC PIC X(4000).
       FD  FI11
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI11-REC PIC X(4000).
       FD  FI12
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI12-REC PIC X(4000).
       FD  FI13
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI13-REC PIC X(4000).
       FD  FI14
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI14-REC PIC X(4000).
       FD  FI15
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI15-REC PIC X(4000).
       FD  FI16
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI16-REC PIC X(4000).
       FD  FI17
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI17-REC PIC X(4000).
       FD  FI18
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI18-REC PIC X(4000).
       FD  FI19
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI19-REC PIC X(4000).
       FD  FI20
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI20-REC PIC X(4000).
       FD  FI21
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI21-REC PIC X(4000).
       FD  FI22
           LABEL RECORD STANDARD
           RECORD VARYING IN SIZE FROM 1 TO 4000
           DEPENDING ON WS-IN-LEN.
       01  FI22-REC PIC X(4000).
       FD  FO1
           LABEL RECORD STANDARD.
       01  FO1-REC PIC X(4000).
       FD  FO2
           LABEL RECORD STANDARD.
       01  FO2-REC PIC X(4000).
       FD  FO3
           LABEL RECORD STANDARD.
       01  FO3-REC PIC X(4000).
       FD  FO4
           LABEL RECORD STANDARD.
       01  FO4-REC PIC X(4000).
       FD  FO5
           LABEL RECORD STANDARD.
       01  FO5-REC PIC X(4000).
       FD  FO6
           LABEL RECORD STANDARD.
       01  FO6-REC PIC X(4000).
       FD  FO7
           LABEL RECORD STANDARD.
       01  FO7-REC PIC X(4000).
       FD  FO8
           LABEL RECORD STANDARD.
       01  FO8-REC PIC X(4000).
       FD  FO9
           LABEL RECORD STANDARD.
       01  FO9-REC PIC X(4000).
       FD  FO10
           LABEL RECORD STANDARD.
       01  FO10-REC PIC X(4000).
       FD  FO11
           LABEL RECORD STANDARD.
       01  FO11-REC PIC X(4000).
       FD  FO12
           LABEL RECORD STANDARD.
       01  FO12-REC PIC X(4000).
       FD  FO13
           LABEL RECORD STANDARD.
       01  FO13-REC PIC X(4000).
       FD  FO14
           LABEL RECORD STANDARD.
       01  FO14-REC PIC X(4000).
       FD  FO15
           LABEL RECORD STANDARD.
       01  FO15-REC PIC X(4000).
       FD  FO16
           LABEL RECORD STANDARD.
       01  FO16-REC PIC X(4000).
       FD  FO17
           LABEL RECORD STANDARD.
       01  FO17-REC PIC X(4000).
       FD  FO18
           LABEL RECORD STANDARD.
       01  FO18-REC PIC X(4000).
       FD  FO19
           LABEL RECORD STANDARD.
       01  FO19-REC PIC X(4000).
       FD  FO20
           LABEL RECORD STANDARD.
       01  FO20-REC PIC X(4000).
       FD  FO21
           LABEL RECORD STANDARD.
       01  FO21-REC PIC X(4000).
       WORKING-STORAGE SECTION.
       01  RECIN              PIC X(4000).
       01  RECOUT             PIC X(4000).
       01  IN-NAMES-V.
           03 FILLER PIC X(30) VALUE 'A1'.
           03 FILLER PIC X(30) VALUE 'F12VIER01A'.
           03 FILLER PIC X(30) VALUE 'FILEIN'.
           03 FILLER PIC X(30) VALUE 'FIN'.
           03 FILLER PIC X(30) VALUE 'I005T0000810'.
           03 FILLER PIC X(30) VALUE 'I006KTMAJ1'.
           03 FILLER PIC X(30) VALUE 'I006SANTE'.
           03 FILLER PIC X(30) VALUE 'I008CLOA35D'.
           03 FILLER PIC X(30) VALUE 'ID50KTMAJ1'.
           03 FILLER PIC X(30) VALUE 'ina'.
           03 FILLER PIC X(30) VALUE 'INACLOA43'.
           03 FILLER PIC X(30) VALUE 'INASC'.
           03 FILLER PIC X(30) VALUE 'INB'.
           03 FILLER PIC X(30) VALUE 'INP'.
           03 FILLER PIC X(30) VALUE 'IPBA07CO99SS'.
           03 FILLER PIC X(30) VALUE 'IPBGA02HIDS'.
           03 FILLER PIC X(30) VALUE 'IRESSG'.
           03 FILLER PIC X(30) VALUE 'IVGR002RES'.
           03 FILLER PIC X(30) VALUE 'IVIB151BAB'.
           03 FILLER PIC X(30) VALUE 'IVIR002CCH'.
           03 FILLER PIC X(30) VALUE 'IVIR002CLO'.
           03 FILLER PIC X(30) VALUE 'IVIR002RAD'.
       01  IN-NAMES REDEFINES IN-NAMES-V.
           03 IN-NM PIC X(30) OCCURS 22.
       01  OUT-NAMES-V.
           03 FILLER PIC X(30) VALUE 'A2'.
           03 FILLER PIC X(30) VALUE 'F006KTMAJ3'.
           03 FILLER PIC X(30) VALUE 'FD50KTMAJ3'.
           03 FILLER PIC X(30) VALUE 'FILEOUT'.
           03 FILLER PIC X(30) VALUE 'FOUT'.
           03 FILLER PIC X(30) VALUE 'I005TABSACHG'.
           03 FILLER PIC X(30) VALUE 'I008CLOA35E'.
           03 FILLER PIC X(30) VALUE 'INC'.
           03 FILLER PIC X(30) VALUE 'IPBA07CO99N'.
           03 FILLER PIC X(30) VALUE 'IPBGA02HIDT'.
           03 FILLER PIC X(30) VALUE 'IVGR002RES2'.
           03 FILLER PIC X(30) VALUE 'IVIB151CFH'.
           03 FILLER PIC X(30) VALUE 'IVIR002CCHT'.
           03 FILLER PIC X(30) VALUE 'IVIR002CLOT'.
           03 FILLER PIC X(30) VALUE 'IVIR002RADT'.
           03 FILLER PIC X(30) VALUE 'OUT'.
           03 FILLER PIC X(30) VALUE 'OUTA'.
           03 FILLER PIC X(30) VALUE 'OUTASC'.
           03 FILLER PIC X(30) VALUE 'OUTCLOA43'.
           03 FILLER PIC X(30) VALUE 'R006SOINSA'.
           03 FILLER PIC X(30) VALUE 'REPIN033'.
       01  OUT-NAMES REDEFINES OUT-NAMES-V.
           03 OUT-NM PIC X(30) OCCURS 21.
       77  IX-IN              PIC 9(3) COMP VALUE 0.
       77  IX-OUT             PIC 9(3) COMP VALUE 0.
       77  NB-LUS             PIC 9(10) COMP VALUE 0.
       01  SWITCHES.
           03  REC-SKIPPED    PIC S9(6) VALUE ZEROES.
       77  WS-INNAME          PIC X(30) VALUE SPACES.
       77  WS-OUTNAME         PIC X(30) VALUE SPACES.
       77  WS-IN-LEN          PIC 9(5) COMP VALUE 0.
       77  WS-OUT-LEN         PIC 9(5) COMP VALUE 0.
       77  P-INLEN            PIC 9(5) COMP VALUE 0.
       77  P-OUTLEN           PIC 9(5) COMP VALUE 0.
       77  P-SKIP             PIC 9(5) COMP VALUE 0.
       77  N-MV               PIC 9(3) COMP VALUE 0.
       77  N-FX               PIC 9(3) COMP VALUE 0.
       77  I                  PIC 9(3) COMP VALUE 0.
       77  CP-LEN             PIC 9(5) COMP VALUE 0.
       01  MV-TAB.
           03  MV-ENT OCCURS 30.
               05  MV-IS      PIC 9(5) COMP.
               05  MV-IL      PIC 9(5) COMP.
               05  MV-OS      PIC 9(5) COMP.
               05  MV-OL      PIC 9(5) COMP.
       01  FX-TAB.
           03  FX-ENT OCCURS 20.
               05  FX-OS      PIC 9(5) COMP.
               05  FX-LEN     PIC 9(5) COMP.
               05  FX-TXT     PIC X(238).
       01  WS-IN              PIC X(4000).
       01  WS-OUT             PIC X(4000).
       PROCEDURE DIVISION.
       DEBUT.
           OPEN INPUT PARMF.
       PARM-LECT.
           READ PARMF AT END GO TO PARM-FIN.
           IF P-TYPE = 'IN'
              MOVE PF-NAME TO WS-INNAME
              MOVE PF-LEN TO P-INLEN.
           IF P-TYPE = 'OU'
              MOVE PF-NAME TO WS-OUTNAME
              MOVE PF-LEN TO P-OUTLEN.
           IF P-TYPE = 'MV'
              ADD 1 TO N-MV
              MOVE PM-IS TO MV-IS (N-MV)
              MOVE PM-IL TO MV-IL (N-MV)
              MOVE PM-OS TO MV-OS (N-MV)
              MOVE PM-OL TO MV-OL (N-MV).
           IF P-TYPE = 'FX'
              ADD 1 TO N-FX
              MOVE PX-OS TO FX-OS (N-FX)
              MOVE PX-LEN TO FX-LEN (N-FX)
              MOVE PX-TXT TO FX-TXT (N-FX).
           IF P-TYPE = 'SK'
              MOVE PS-N TO P-SKIP.
           GO TO PARM-LECT.
       PARM-FIN.
           CLOSE PARMF.
           MOVE 1 TO IX-IN.
           MOVE 1 TO IX-OUT.
       FIND-IN.
           IF IX-IN > 22 GO TO FINW.
           IF IN-NM (IX-IN) = WS-INNAME GO TO FIND-OUT.
           ADD 1 TO IX-IN.
           GO TO FIND-IN.
       FIND-OUT.
           IF IX-OUT > 21 GO TO FINW.
           IF OUT-NM (IX-OUT) = WS-OUTNAME GO TO OPEN-FILES.
           ADD 1 TO IX-OUT.
           GO TO FIND-OUT.
       OPEN-FILES.
           GO TO
                 OI-1 OI-2 OI-3 OI-4 OI-5
                 OI-6 OI-7 OI-8 OI-9 OI-10
                 OI-11 OI-12 OI-13 OI-14 OI-15
                 OI-16 OI-17 OI-18 OI-19 OI-20
                 OI-21 OI-22
             DEPENDING ON IX-IN.
       OI-1.
           OPEN INPUT FI1.
           GO TO OI-END.
       OI-2.
           OPEN INPUT FI2.
           GO TO OI-END.
       OI-3.
           OPEN INPUT FI3.
           GO TO OI-END.
       OI-4.
           OPEN INPUT FI4.
           GO TO OI-END.
       OI-5.
           OPEN INPUT FI5.
           GO TO OI-END.
       OI-6.
           OPEN INPUT FI6.
           GO TO OI-END.
       OI-7.
           OPEN INPUT FI7.
           GO TO OI-END.
       OI-8.
           OPEN INPUT FI8.
           GO TO OI-END.
       OI-9.
           OPEN INPUT FI9.
           GO TO OI-END.
       OI-10.
           OPEN INPUT FI10.
           GO TO OI-END.
       OI-11.
           OPEN INPUT FI11.
           GO TO OI-END.
       OI-12.
           OPEN INPUT FI12.
           GO TO OI-END.
       OI-13.
           OPEN INPUT FI13.
           GO TO OI-END.
       OI-14.
           OPEN INPUT FI14.
           GO TO OI-END.
       OI-15.
           OPEN INPUT FI15.
           GO TO OI-END.
       OI-16.
           OPEN INPUT FI16.
           GO TO OI-END.
       OI-17.
           OPEN INPUT FI17.
           GO TO OI-END.
       OI-18.
           OPEN INPUT FI18.
           GO TO OI-END.
       OI-19.
           OPEN INPUT FI19.
           GO TO OI-END.
       OI-20.
           OPEN INPUT FI20.
           GO TO OI-END.
       OI-21.
           OPEN INPUT FI21.
           GO TO OI-END.
       OI-22.
           OPEN INPUT FI22.
           GO TO OI-END.
       OI-END.
           GO TO
                 OO-1 OO-2 OO-3 OO-4 OO-5
                 OO-6 OO-7 OO-8 OO-9 OO-10
                 OO-11 OO-12 OO-13 OO-14 OO-15
                 OO-16 OO-17 OO-18 OO-19 OO-20
                 OO-21
             DEPENDING ON IX-OUT.
       OO-1.
           OPEN OUTPUT FO1.
           GO TO OO-END.
       OO-2.
           OPEN OUTPUT FO2.
           GO TO OO-END.
       OO-3.
           OPEN OUTPUT FO3.
           GO TO OO-END.
       OO-4.
           OPEN OUTPUT FO4.
           GO TO OO-END.
       OO-5.
           OPEN OUTPUT FO5.
           GO TO OO-END.
       OO-6.
           OPEN OUTPUT FO6.
           GO TO OO-END.
       OO-7.
           OPEN OUTPUT FO7.
           GO TO OO-END.
       OO-8.
           OPEN OUTPUT FO8.
           GO TO OO-END.
       OO-9.
           OPEN OUTPUT FO9.
           GO TO OO-END.
       OO-10.
           OPEN OUTPUT FO10.
           GO TO OO-END.
       OO-11.
           OPEN OUTPUT FO11.
           GO TO OO-END.
       OO-12.
           OPEN OUTPUT FO12.
           GO TO OO-END.
       OO-13.
           OPEN OUTPUT FO13.
           GO TO OO-END.
       OO-14.
           OPEN OUTPUT FO14.
           GO TO OO-END.
       OO-15.
           OPEN OUTPUT FO15.
           GO TO OO-END.
       OO-16.
           OPEN OUTPUT FO16.
           GO TO OO-END.
       OO-17.
           OPEN OUTPUT FO17.
           GO TO OO-END.
       OO-18.
           OPEN OUTPUT FO18.
           GO TO OO-END.
       OO-19.
           OPEN OUTPUT FO19.
           GO TO OO-END.
       OO-20.
           OPEN OUTPUT FO20.
           GO TO OO-END.
       OO-21.
           OPEN OUTPUT FO21.
           GO TO OO-END.
       OO-END.
       LECT.
           MOVE SPACES TO WS-OUT.
           MOVE SPACES TO RECIN.
           GO TO
                 RD-1 RD-2 RD-3 RD-4 RD-5
                 RD-6 RD-7 RD-8 RD-9 RD-10
                 RD-11 RD-12 RD-13 RD-14 RD-15
                 RD-16 RD-17 RD-18 RD-19 RD-20
                 RD-21 RD-22
             DEPENDING ON IX-IN.
       RD-1.
           READ FI1 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-2.
           READ FI2 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-3.
           READ FI3 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-4.
           READ FI4 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-5.
           READ FI5 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-6.
           READ FI6 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-7.
           READ FI7 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-8.
           READ FI8 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-9.
           READ FI9 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-10.
           READ FI10 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-11.
           READ FI11 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-12.
           READ FI12 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-13.
           READ FI13 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-14.
           READ FI14 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-15.
           READ FI15 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-16.
           READ FI16 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-17.
           READ FI17 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-18.
           READ FI18 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-19.
           READ FI19 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-20.
           READ FI20 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-21.
           READ FI21 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-22.
           READ FI22 INTO RECIN AT END GO TO FINW.
           GO TO RD-END.
       RD-END.
           MOVE SPACES TO WS-IN.
           MOVE WS-IN-LEN TO CP-LEN.
           IF CP-LEN > P-INLEN
              MOVE P-INLEN TO CP-LEN.
           IF CP-LEN > 0
              MOVE RECIN (1:CP-LEN) TO WS-IN (1:CP-LEN).
           IF N-MV = 0
              MOVE WS-IN (1:P-INLEN) TO WS-OUT (1:P-OUTLEN).
           MOVE 1 TO I.
       MV-LOOP.
           IF I > N-MV GO TO FX-START.
           MOVE WS-IN (MV-IS (I):MV-IL (I))
             TO WS-OUT (MV-OS (I):MV-OL (I)).
           ADD 1 TO I.
           GO TO MV-LOOP.
       FX-START.
           MOVE 1 TO I.
       FX-LOOP.
           IF I > N-FX GO TO REC-END.
           MOVE FX-TXT (I) (1:FX-LEN (I))
             TO WS-OUT (FX-OS (I):FX-LEN (I)).
           INSPECT WS-OUT (FX-OS (I):FX-LEN (I))
             REPLACING ALL '<' BY ';'.
           ADD 1 TO I.
           GO TO FX-LOOP.
       REC-END.
           ADD 1 TO NB-LUS.
           IF NB-LUS < P-SKIP
              ADD 1 TO REC-SKIPPED
              GO TO LECT.
           MOVE P-OUTLEN TO WS-OUT-LEN.
           MOVE WS-OUT TO RECOUT.
           GO TO
                 WR-1 WR-2 WR-3 WR-4 WR-5
                 WR-6 WR-7 WR-8 WR-9 WR-10
                 WR-11 WR-12 WR-13 WR-14 WR-15
                 WR-16 WR-17 WR-18 WR-19 WR-20
                 WR-21
             DEPENDING ON IX-OUT.
       WR-1.
           WRITE FO1-REC FROM RECOUT.
           GO TO WR-END.
       WR-2.
           WRITE FO2-REC FROM RECOUT.
           GO TO WR-END.
       WR-3.
           WRITE FO3-REC FROM RECOUT.
           GO TO WR-END.
       WR-4.
           WRITE FO4-REC FROM RECOUT.
           GO TO WR-END.
       WR-5.
           WRITE FO5-REC FROM RECOUT.
           GO TO WR-END.
       WR-6.
           WRITE FO6-REC FROM RECOUT.
           GO TO WR-END.
       WR-7.
           WRITE FO7-REC FROM RECOUT.
           GO TO WR-END.
       WR-8.
           WRITE FO8-REC FROM RECOUT.
           GO TO WR-END.
       WR-9.
           WRITE FO9-REC FROM RECOUT.
           GO TO WR-END.
       WR-10.
           WRITE FO10-REC FROM RECOUT.
           GO TO WR-END.
       WR-11.
           WRITE FO11-REC FROM RECOUT.
           GO TO WR-END.
       WR-12.
           WRITE FO12-REC FROM RECOUT.
           GO TO WR-END.
       WR-13.
           WRITE FO13-REC FROM RECOUT.
           GO TO WR-END.
       WR-14.
           WRITE FO14-REC FROM RECOUT.
           GO TO WR-END.
       WR-15.
           WRITE FO15-REC FROM RECOUT.
           GO TO WR-END.
       WR-16.
           WRITE FO16-REC FROM RECOUT.
           GO TO WR-END.
       WR-17.
           WRITE FO17-REC FROM RECOUT.
           GO TO WR-END.
       WR-18.
           WRITE FO18-REC FROM RECOUT.
           GO TO WR-END.
       WR-19.
           WRITE FO19-REC FROM RECOUT.
           GO TO WR-END.
       WR-20.
           WRITE FO20-REC FROM RECOUT.
           GO TO WR-END.
       WR-21.
           WRITE FO21-REC FROM RECOUT.
           GO TO WR-END.
       WR-END.
           GO TO LECT.
       FINW.
           DISPLAY  '*CFH-COPY  FIN*'  UPON  PRINTER.
           DISPLAY  '*NB-ENREG-LUS ='  NB-LUS  UPON  PRINTER.
           IF IX-IN > 22 GO TO CI-END.
           GO TO
                 CI-1 CI-2 CI-3 CI-4 CI-5
                 CI-6 CI-7 CI-8 CI-9 CI-10
                 CI-11 CI-12 CI-13 CI-14 CI-15
                 CI-16 CI-17 CI-18 CI-19 CI-20
                 CI-21 CI-22
             DEPENDING ON IX-IN.
       CI-1.
           CLOSE FI1.
           GO TO CI-END.
       CI-2.
           CLOSE FI2.
           GO TO CI-END.
       CI-3.
           CLOSE FI3.
           GO TO CI-END.
       CI-4.
           CLOSE FI4.
           GO TO CI-END.
       CI-5.
           CLOSE FI5.
           GO TO CI-END.
       CI-6.
           CLOSE FI6.
           GO TO CI-END.
       CI-7.
           CLOSE FI7.
           GO TO CI-END.
       CI-8.
           CLOSE FI8.
           GO TO CI-END.
       CI-9.
           CLOSE FI9.
           GO TO CI-END.
       CI-10.
           CLOSE FI10.
           GO TO CI-END.
       CI-11.
           CLOSE FI11.
           GO TO CI-END.
       CI-12.
           CLOSE FI12.
           GO TO CI-END.
       CI-13.
           CLOSE FI13.
           GO TO CI-END.
       CI-14.
           CLOSE FI14.
           GO TO CI-END.
       CI-15.
           CLOSE FI15.
           GO TO CI-END.
       CI-16.
           CLOSE FI16.
           GO TO CI-END.
       CI-17.
           CLOSE FI17.
           GO TO CI-END.
       CI-18.
           CLOSE FI18.
           GO TO CI-END.
       CI-19.
           CLOSE FI19.
           GO TO CI-END.
       CI-20.
           CLOSE FI20.
           GO TO CI-END.
       CI-21.
           CLOSE FI21.
           GO TO CI-END.
       CI-22.
           CLOSE FI22.
           GO TO CI-END.
       CI-END.
           IF IX-OUT > 21 GO TO CO-END.
           GO TO
                 CO-1 CO-2 CO-3 CO-4 CO-5
                 CO-6 CO-7 CO-8 CO-9 CO-10
                 CO-11 CO-12 CO-13 CO-14 CO-15
                 CO-16 CO-17 CO-18 CO-19 CO-20
                 CO-21
             DEPENDING ON IX-OUT.
       CO-1.
           CLOSE FO1.
           GO TO CO-END.
       CO-2.
           CLOSE FO2.
           GO TO CO-END.
       CO-3.
           CLOSE FO3.
           GO TO CO-END.
       CO-4.
           CLOSE FO4.
           GO TO CO-END.
       CO-5.
           CLOSE FO5.
           GO TO CO-END.
       CO-6.
           CLOSE FO6.
           GO TO CO-END.
       CO-7.
           CLOSE FO7.
           GO TO CO-END.
       CO-8.
           CLOSE FO8.
           GO TO CO-END.
       CO-9.
           CLOSE FO9.
           GO TO CO-END.
       CO-10.
           CLOSE FO10.
           GO TO CO-END.
       CO-11.
           CLOSE FO11.
           GO TO CO-END.
       CO-12.
           CLOSE FO12.
           GO TO CO-END.
       CO-13.
           CLOSE FO13.
           GO TO CO-END.
       CO-14.
           CLOSE FO14.
           GO TO CO-END.
       CO-15.
           CLOSE FO15.
           GO TO CO-END.
       CO-16.
           CLOSE FO16.
           GO TO CO-END.
       CO-17.
           CLOSE FO17.
           GO TO CO-END.
       CO-18.
           CLOSE FO18.
           GO TO CO-END.
       CO-19.
           CLOSE FO19.
           GO TO CO-END.
       CO-20.
           CLOSE FO20.
           GO TO CO-END.
       CO-21.
           CLOSE FO21.
           GO TO CO-END.
       CO-END.
           DISPLAY  REC-SKIPPED  UPON  PRINTER.
           STOP RUN.
