# Spike step 3: run the 177a-rebuilt generic CFH-COPY (-GF) in the mock system on both references, same DLL, parameter file per call.
param([String]$Binaries = 'E:\AMT_Work\Rebuild177a-spike\AFBUS_2200COBOL\Binaries\Programs', [String]$Dll = 'ASSURFED_UTILIT_CFH_COPY_GF.dll')
$ErrorActionPreference = 'Stop'
$mt = 'E:\Repos\SsgTrial\Conversion\Pipeline\MockTest'
. "$mt\MockFc.ps1"
$chk = 'E:\Repos\SsgTrial\_scratch\spike-cfh\check'
$m = 'E:\AMT_Work\MockTest'
$cases = @(
  @{ Case = 'GF_AFPH12_L427'; Inputs = @{ SGSPARM = "$chk\parm\AFPH12_L427.parm"; INASC = "$m\AFPH12_L427\input\INASC" }; Name = 'OUTASC'; Exp = "$m\AFPH12_L427\expected\OUTASC" },
  @{ Case = 'GF_VIRM01_L484'; Inputs = @{ SGSPARM = "$chk\parm\VIRM01_CO_L484.parm"; INB = "$m\VIRM01\input\INB" }; Name = 'INC'; Exp = "$m\VIRM01\expected\INC" }
)
try {
  foreach ($c in $cases) {
    Start-MockFc
    $r = & "$mt\Run-ProgramCase.ps1" -Case $c.Case -Dll $Dll -Inputs $c.Inputs -ExpectedName $c.Name -ExpectedFile $c.Exp -Binaries $Binaries
    '{0,-16} {1,-5} {2}' -f $r.Case, $r.Result, $r.Detail
  }
} finally { Stop-MockFc }
