# Spike (MT-043, name-free): deploy (delivery: Deliver-GnPrograms.ps1), the SSG4 scripts with the fixed-names hand-off,
# stage inputs and cards for AFPH12, VIRM01 and NEWNAME (AFPH12's data under names no program knows).
$ErrorActionPreference = 'Stop'
$out = 'E:\Repos\SsgTrial\_scratch\spike-cfh\prepare-gn.txt'
$x = 'E:\Repos\Federale_InternalRelease\AmtTools\Basepaths\Extracts'
$prog = 'E:\Repos\AMT\Apps\AFBUS_2200COBOL_AMT\Binaries\Programs'
$cards = 'E:\Repos\ssg4-work\sgs-cards\calls'
$r = @()
$r += pwsh -NoProfile -File E:\Repos\SsgTrial\_scratch\ecl-pilot\Deploy-EclPilot.ps1 -Generic -Program ASSURFED_UTILIT_CFH_COPY_GN -FixedNames
New-Item -ItemType Directory -Force "$x\ASSURFED", "$x\P`$SGS" | Out-Null
Copy-Item E:\AMT_Work\MockTest\AFPH12_L427\input\INASC "$x\ASSURFED\IAFB011FAI" -Force
Copy-Item E:\AMT_Work\MockTest\AFPH12_L427\input\INASC "$x\ASSURFED\ZZTESTIN" -Force
Copy-Item E:\AMT_Work\MockTest\VIRM01\input\INB "$x\ASSURFED\I006VRM01ATT" -Force
Copy-Item "$cards\ASSURFED_F999RUN_AFPH12__L427.sgs" "$x\P`$SGS\AFPH12" -Force
Copy-Item "$cards\ASSURFED_F999RUN_VIRM01_CO__L484.sgs" "$x\P`$SGS\VIRM01" -Force
$nn = (Get-Content -Raw "$cards\ASSURFED_F999RUN_AFPH12__L427.sgs") -replace '\bINASC\b', 'ZZNEWIN' -replace '\bOUTASC\b', 'ZZNEWOUT'
[IO.File]::WriteAllText("$x\P`$SGS\NEWNAME", $nn)
Copy-Item E:\AMT_Work\MockTest\VIRM01_UL\input\I006KTMAJ1 "$x\ASSURFED\I006KTMAJ1" -Force
Copy-Item "$cards\ASSURFED_F999RUN_VIRM01_UL__L160.sgs" "$x\P`$SGS\VIRM01UL" -Force
foreach ($old in 'IAFB012FAI.DAT', 'I006VRM01ATC', 'I006VRM01ATC.DAT', 'ZZTESTOUT', 'ZZTESTOUT.DAT', 'F006KTMAJ3', 'F006KTMAJ3.DAT', 'CFHPARM') { if (Test-Path "$x\ASSURFED\$old") { Remove-Item "$x\ASSURFED\$old" -Force; $r += "removed old ASSURFED\$old" } }
$r += Get-ChildItem "$x\ASSURFED", "$x\P`$SGS" -File | ForEach-Object { 'staged {0} {1:N0} B' -f $_.FullName.Substring($x.Length + 1), $_.Length }
$cc = @(
  [pscustomobject]@{ Case = 'AFPH12'; Actual = "$x\ASSURFED\IAFB012FAI"; Expected = 'E:\AMT_Work\MockTest\AFPH12_L427\expected\OUTASC' }
  [pscustomobject]@{ Case = 'VIRM01'; Actual = "$x\ASSURFED\I006VRM01ATC"; Expected = 'E:\AMT_Work\MockTest\VIRM01\expected\INC' }
  [pscustomobject]@{ Case = 'NEWNAME'; Actual = "$x\ASSURFED\ZZTESTOUT"; Expected = 'E:\AMT_Work\MockTest\AFPH12_L427\expected\OUTASC' }
  [pscustomobject]@{ Case = 'VIRM01UL'; Actual = "$x\ASSURFED\F006KTMAJ3"; Expected = 'E:\AMT_Work\MockTest\VIRM01_UL\expected\F006KTMAJ3' })
$cc | ConvertTo-Json | Set-Content 'E:\Repos\SsgTrial\_scratch\spike-cfh\cc-cases.json'
$r | Out-File $out
$r
