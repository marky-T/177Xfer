# Members of the ComScript file API (IFile*, IFileBinaryStream, IFileInfo) the hand-off can use through $global:AmtFile.
$dir = 'E:\Repos\Federale_InternalRelease\AmtTools\ComScript'
$out = 'E:\Repos\SsgTrial\_scratch\spike-loadis\check\filestream-api.txt'
[AppDomain]::CurrentDomain.add_AssemblyResolve({ param($s, $e) $p = Join-Path $dir (($e.Name -split ',')[0] + '.dll'); if (Test-Path $p) { [Reflection.Assembly]::LoadFrom($p) } })
$lines = foreach ($dll in Get-ChildItem $dir -Filter '*.dll') {
  try { $a = [Reflection.Assembly]::LoadFrom($dll.FullName); $types = $a.GetTypes() } catch [Reflection.ReflectionTypeLoadException] { $types = $_.Exception.Types | Where-Object { $_ } } catch { continue }
  foreach ($t in $types | Where-Object { $_.FullName -match 'Scripting\.(IFile\w*|IAmtFile\w*)$' }) {
    "== $($t.FullName) ($($dll.Name))"
    foreach ($m in $t.GetMethods()) { '   {0} {1}({2})' -f $m.ReturnType.Name, $m.Name, (($m.GetParameters() | ForEach-Object { "$($_.ParameterType.Name) $($_.Name)" }) -join ', ') }
  }
}
[IO.File]::WriteAllLines($out, [string[]]$lines)
"written $out ($($lines.Count) lines)"
