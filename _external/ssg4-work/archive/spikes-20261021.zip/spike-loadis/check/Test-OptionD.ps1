# Option D check (LOADIS/UNLOADIS spike): does a program that declares one key read an indexed file whose .Index header holds
# another key? The static UNLOADIS_ASCII (declares key 6,8, record 204) reads a copy of a real 204-byte file whose header key
# offset is patched from 6 to 7. Control: the same file with the header unchanged.
param([String]$Binaries = 'E:\AMT_Work\Rebuild177a-spike\AFBUS_2200COBOL\Binaries\Programs')
$ErrorActionPreference = 'Continue'
$mt = 'E:\Repos\SsgTrial\Conversion\Pipeline\MockTest'
$src = 'E:\Repos\SsgTrial\_scratch\cc-runs\LOADIS_ASCII\OUTCLOA49.DAT'
$root = 'E:\AMT_Work\MockTest\LOADIS_D'
New-Item -ItemType Directory -Force "$root\ctl", "$root\bad" | Out-Null
$hdr = [IO.File]::ReadAllBytes("$src.Index")
# key offset / length are little-endian ints right after the 01 01 01 00 00 00 marker (seen at 0x115 / 0x119)
$pos = -1
for ($i = 0x100; $i -lt 0x140; $i++) { if ($hdr[$i] -eq 6 -and $hdr[$i + 1] -eq 0 -and $hdr[$i + 4] -eq 8 -and $hdr[$i + 5] -eq 0) { $pos = $i; break } }
if ($pos -lt 0) { throw 'key offset/length (6,8) not found in header' }
"header key offset at 0x{0:X}" -f $pos
foreach ($v in 'ctl', 'bad') {
  Copy-Item $src "$root\$v\FSCR001ATO" -Force
  $b = [byte[]]$hdr.Clone()
  if ($v -eq 'bad') { $b[$pos] = 7 }
  [IO.File]::WriteAllBytes("$root\$v\FSCR001ATO.Index", $b)
}
. "$mt\MockFc.ps1"
foreach ($v in 'ctl', 'bad') {
  try {
    Start-MockFc
    $r = & "$mt\Run-ProgramCase.ps1" -Case "LOADIS_D_$v" -Dll ASSURFED_UTILIT_UNLOADIS_ASCII.dll -Inputs @{ FSCR001ATO = "$root\$v\FSCR001ATO" } -ExpectedName OUT -ExpectedFile $src -Binaries $Binaries
    '{0}: {1} {2}' -f $v, $r.Result, $r.Detail
  } finally { Stop-MockFc }
}
