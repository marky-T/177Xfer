# Dumps the header of the two CC-written .Index files side by side, to decode the bytes we only copied so far.
$out = 'E:\Repos\SsgTrial\_scratch\spike-loadis\check\index-headers.txt'
$files = 'E:\Repos\SsgTrial\_scratch\cc-runs\LOADIS_ASCII\OUTCLOA49.DAT.Index', 'E:\Repos\SsgTrial\_scratch\cc-runs\LOADIS_MULTI\F006GRS.DAT.Index'
$lines = foreach ($f in $files) {
  $b = [IO.File]::ReadAllBytes($f)
  "== $f ($($b.Length) bytes)"
  $n = [Math]::Min($b.Length, 0x150)
  for ($o = 0; $o -lt $n; $o += 16) {
    $c = [Math]::Min(16, $n - $o)
    $hex = ($b[$o..($o + $c - 1)] | ForEach-Object { $_.ToString('X2') }) -join ' '
    $txt = [Text.Encoding]::ASCII.GetString($b, $o, $c) -replace '[^\x20-\x7E]', '.'
    '{0:X4}: {1,-47}  {2}' -f $o, $hex, $txt
  }
}
[IO.File]::WriteAllLines($out, [string[]]$lines)
"written $out"
