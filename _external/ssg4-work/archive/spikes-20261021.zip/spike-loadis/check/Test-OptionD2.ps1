# Option D, decisive version: physical order differs from key order, and a header key that differs from the declared key.
# Static UNLOADIS_ASCII declares key (6,8). Cases:
#   rev   : DAT records reversed, index (6,8) rebuilt to match  -> index used = original order; physical = reversed
#   hdr20 : original DAT, a valid index on key (20,8)           -> header honoured = order by bytes 20..27; else original / error
param([String]$Binaries = 'E:\AMT_Work\Rebuild177a-spike\AFBUS_2200COBOL\Binaries\Programs')
$ErrorActionPreference = 'Continue'
$mt = 'E:\Repos\SsgTrial\Conversion\Pipeline\MockTest'
$src = 'E:\Repos\SsgTrial\_scratch\cc-runs\LOADIS_ASCII\OUTCLOA49.DAT'
$root = 'E:\AMT_Work\MockTest\LOADIS_D2'
New-Item -ItemType Directory -Force $root | Out-Null
$asc = [Text.Encoding]::GetEncoding(28591)
$d = [IO.File]::ReadAllBytes($src); $hdrSrc = [IO.File]::ReadAllBytes("$src.Index")
$n = $d.Length / 206
$recs = 0..($n - 1) | ForEach-Object { , $d[($_ * 206)..($_ * 206 + 205)] }
$keyOf = { param($r, $o) $asc.GetString($r, $o, 8) }
function Write-Case($name, $recList, $off) {
  $ms = [IO.MemoryStream]::new(); foreach ($r in $recList) { $ms.Write($r, 0, 206) }
  [IO.File]::WriteAllBytes("$root\$name", $ms.ToArray())
  $h = [byte[]]$hdrSrc[0..0x126]                     # header up to the first entry
  [BitConverter]::GetBytes([int]$off).CopyTo($h, 0x115)
  $entries = for ($i = 0; $i -lt $recList.Count; $i++) { [pscustomobject]@{ K = (& $keyOf $recList[$i] $off); R = $i } }
  $entries = [Linq.Enumerable]::OrderBy([object[]]$entries, [Func[object, string]] { $args[0].K }, [StringComparer]::Ordinal)
  $ix = [IO.MemoryStream]::new(); $ix.Write($h, 0, $h.Length)
  foreach ($e in $entries) { $ix.Write($asc.GetBytes($e.K), 0, 8); $ix.Write([BitConverter]::GetBytes([long]$e.R), 0, 8) }
  [IO.File]::WriteAllBytes("$root\$name.Index", $ix.ToArray())
}
function Save-Order($name, $recList) { $ms = [IO.MemoryStream]::new(); foreach ($r in $recList) { $ms.Write($r, 0, 206) }; [IO.File]::WriteAllBytes("$root\$name", $ms.ToArray()) }
$rev = [object[]]$recs.Clone(); [Array]::Reverse($rev)
Write-Case 'rev' $rev 6
Write-Case 'hdr20' $recs 20
# sanity: rebuilding the original index this way must reproduce it byte for byte
Write-Case 'orig' $recs 6
'rebuilt original index identical: ' + ((Get-FileHash "$root\orig.Index").Hash -eq (Get-FileHash "$src.Index").Hash)
Save-Order 'exp-original' $recs
Save-Order 'exp-reversed' $rev
Save-Order 'exp-by20' ([Linq.Enumerable]::OrderBy([object[]]$recs, [Func[object, string]] { $asc.GetString($args[0], 20, 8) }, [StringComparer]::Ordinal))
. "$mt\MockFc.ps1"
foreach ($c in 'rev', 'hdr20') {
  try {
    Start-MockFc
    $r = & "$mt\Run-ProgramCase.ps1" -Case "LOADIS_D2_$c" -Dll ASSURFED_UTILIT_UNLOADIS_ASCII.dll -Inputs @{ FSCR001ATO = "$root\$c" } -ExpectedName OUT -ExpectedFile $src -KeepOutputAs OUT -KeepOutputTo "$root\out-$c" -Binaries $Binaries
    "${c}: run $($r.Result) $($r.Detail)"
    if (Test-Path "$root\out-$c") {
      $h = (Get-FileHash "$root\out-$c").Hash
      foreach ($e in 'exp-original', 'exp-reversed', 'exp-by20') { if ((Get-FileHash "$root\$e").Hash -eq $h) { "${c}: output = $e" } }
    } else { "${c}: no output kept" }
  } finally { Stop-MockFc 2>$null }
}
