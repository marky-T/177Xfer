# Logs every file created/deleted under the given roots until the stop file appears (finds short-lived job files).
param([String[]]$Roots = @('E:\Repos', 'E:\Amt', 'E:\AMT_Work', 'C:\ProgramData'), [String]$Log = 'E:\Repos\SsgTrial\_scratch\spike-scangroup\watch.txt')
$stop = "$Log.stop"
Remove-Item $stop, $Log -ErrorAction SilentlyContinue
$q = [System.Collections.Concurrent.ConcurrentQueue[String]]::new()
$ws = foreach ($r in $Roots) {
  try {
    $w = New-Object IO.FileSystemWatcher $r
    $w.IncludeSubdirectories = $true; $w.InternalBufferSize = 65536
    $w.NotifyFilter = [IO.NotifyFilters]'FileName'
    Register-ObjectEvent $w Created | Out-Null; Register-ObjectEvent $w Deleted | Out-Null
    $w.EnableRaisingEvents = $true
    $w
  } catch { "skip $r : $($_.Exception.Message)" | Add-Content $Log }
}
"watching $(@($ws).Count) roots" | Add-Content $Log
while (-not (Test-Path $stop)) {
  Start-Sleep -Milliseconds 300
  foreach ($ev in @(Get-Event)) { $a = $ev.SourceEventArgs; $item = '{0:HH:mm:ss.fff} {1} {2}' -f $ev.TimeGenerated, $a.ChangeType, $a.FullPath; Remove-Event -EventIdentifier $ev.EventIdentifier; if ($item -notmatch 'AppData\\Roaming\\Code|watch\.txt|\\\.git\\') { Add-Content $Log $item } }
}
