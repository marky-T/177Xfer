# SSG-4 (MT-043 / T3-032 probe): do Xqt data lines reach a CARD-READER file? Static CHABAN (NBFOIS 0: reads one card).
Import-Module -Name (Join-Path $PSScriptRoot '..\..\..\Libraries\AmtPsEclLib.psm1') -Force -DisableNameChecking -ErrorAction Stop
Import-Module -Name (Join-Path $PSScriptRoot '..\..\..\Libraries\AmtPsSortLib.psm1') -Force -DisableNameChecking -ErrorAction Stop
$AmtSettingsFile = Join-Path $PSScriptRoot '..\..\Settings\AmtSettings.xml'

Set-Jobname "CHABTEST"
Initialize $AmtSettingsFile

Try {
  Qual "" "CHABTEST"
  $global:CloneReports = @([pscustomobject]@{ Name = 'ASSURFED_UTILIT_CHABAN_ASCII'; Clone = 'CHABAN' })
  Delete "C" ("OUT")
  Asg "P, U" ("OUT")
  Xqt "" ("TPF`$.CHABAN")
  DataLineOrNoStatement ("PROBE CARD ONE 0123456789")
  DataLineOrNoStatement ("PROBE CARD TWO")
  Free "" ("OUT")
  Fin
} Catch [Exception] {
  HandleTrapAndAbort "Error trapped: " $_
} Finally {
  Cleanup $false
}
