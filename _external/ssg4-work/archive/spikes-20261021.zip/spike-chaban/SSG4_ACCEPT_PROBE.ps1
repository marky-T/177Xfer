# SSG-4 (T3-032 probe 2): Xqt data lines read as a normal disk file. CFH-COPY-GN copies whole records from CFHIN, whose
# use name the shared hand-off points at the run's Accept file (*ACCEPT*). Expected OUT: the 5 data lines (one blank, one of 100 bytes), 100 bytes each.
Import-Module -Name (Join-Path $PSScriptRoot '..\..\..\Libraries\AmtPsEclLib.psm1') -Force -DisableNameChecking -ErrorAction Stop
Import-Module -Name (Join-Path $PSScriptRoot '..\..\..\Libraries\AmtPsSortLib.psm1') -Force -DisableNameChecking -ErrorAction Stop
$AmtSettingsFile = Join-Path $PSScriptRoot '..\..\Settings\AmtSettings.xml'

Set-Jobname "ACCTEST"
Initialize $AmtSettingsFile

Try {
  Qual "" "ACCTEST"
  . ([ScriptBlock]::Create((Get-Content -Raw (Join-Path $PSScriptRoot '..\..\ASSURFED_UTILIT\GnHandoff.inc'))))
  Delete "C" ("OUT")
  Asg "P, U" ("OUT")
  Invoke-GnHandoff -Program 'ASSURFED_UTILIT_CFH_COPY_GN' -XqtName 'CFH_COPY' -ParmFile 'CFHPARM' -ParmRecLen 250 `
    -ParmLines @(('IN' + 'CFHIN'.PadRight(30) + '00100'), ('OU' + 'CFHOUT'.PadRight(30) + '00100')) `
    -Files @(@{ Fixed = 'CFHIN'; Call = '*ACCEPT*' }, @{ Fixed = 'CFHOUT'; Call = 'OUT'; RecSize = 100 }) -Label 'ACCEPT probe'
  Xqt "" (".CFH-COPY")
  DataLineOrNoStatement ("PROBE CARD ONE 0123456789")
  DataLineOrNoStatement ("PROBE CARD TWO")
  DataLineOrNoStatement ("")
  DataLineOrNoStatement ("PROBE CARD THREE  END")
  DataLineOrNoStatement ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX0123456789")
  Free "" ("OUT")
  Fin
} Catch [Exception] {
  HandleTrapAndAbort "Error trapped: " $_
} Finally {
  Cleanup $false
}
