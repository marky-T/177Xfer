# Repro: AddTo-SgsList splits a quoted SGS subfield that contains spaces.
# Usage: pwsh -NoProfile -File run.ps1 [-Library <path to AmtPsEclLib.psm1>]
param([String]$Library = 'E:\Repos\Federale_InternalRelease\Scripts\Libraries\AmtPsEclLib.psm1')
$ErrorActionPreference = 'Stop'

# Load only AddTo-SgsList from the library (importing the module would start a job context).
$ast = [System.Management.Automation.Language.Parser]::ParseFile($Library, [ref]$null, [ref]$null)
$fn = $ast.Find({ param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'AddTo-SgsList' }, $true)
if (-not $fn) { throw "AddTo-SgsList not found in $Library" }
. ([ScriptBlock]::Create($fn.Extent.Text))

$global:SgsLabels = New-Object 'System.Collections.Generic.Dictionary[String,Object]' ([StringComparer]::OrdinalIgnoreCase)
$global:CommandLineSgsLabels = ''
$cards = @(
    "LABELA 71,8,' '",
    "LABELB 1,10,'A B C'",
    "LABELC 5,2,X"
)
AddTo-SgsList ($cards -join "`r`n")

$expected = @{
    LABELA = @(, @('71', '8', "' '"))
    LABELB = @(, @('1', '10', "'A B C'"))
    LABELC = @(, @('5', '2', 'X'))
}
$fail = 0
foreach ($card in $cards) {
    $label = ($card -split ' ')[0]
    $fields = $global:SgsLabels[$label][0]
    $got = @(foreach ($f in $fields) { '[' + ($f -join '|') + ']' }) -join ' '
    $want = @(foreach ($f in $expected[$label]) { '[' + ($f -join '|') + ']' }) -join ' '
    $ok = $got -eq $want
    if (-not $ok) { $fail++ }
    '{0,-24} fields {1}  expected {2}  {3}' -f $card, $got, $want, $(if ($ok) { 'OK' } else { 'WRONG' })
}
"result: $fail of $($cards.Count) cards read wrongly"
exit $fail
