# Repro: the ECL converter writes @HDG,P <text> as Hdg "P <text>" (options and heading in one string).
# Usage: pwsh -NoProfile -File run.ps1 -Converter <EclConverterConsole.dll> -Library <AmtPsEclLib.psm1>
param(
    [Parameter(Mandatory)][String]$Converter,
    [Parameter(Mandatory)][String]$Library
)
$ErrorActionPreference = 'Stop'
$work = Join-Path $PSScriptRoot 'out'
Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force "$work\in", "$work\out" | Out-Null
Copy-Item (Join-Path $PSScriptRoot 'TESTRUN.TXT') "$work\in\TESTRUN.TXT"

& dotnet $Converter "/INPUTFILE:$work\in\TESTRUN.TXT" "/OUTPUT:$work\out" *> "$work\converter.log"
$ps1 = Get-ChildItem "$work\out" -Recurse -Filter '*.ps1' | Select-Object -First 1
if (-not $ps1) { Get-Content "$work\converter.log" | Select-Object -Last 15; throw 'no PowerShell written' }
$hdg = @(Select-String -Path $ps1.FullName -Pattern '^\s*Hdg\b' | ForEach-Object { $_.Line.Trim() })
"converted: $($ps1.Name)"
$hdg | ForEach-Object { "  $_" }

# The run-time Hdg takes the options and the heading as separate arguments; check what it accepts.
$ast = [System.Management.Automation.Language.Parser]::ParseFile($Library, [ref]$null, [ref]$null)
$fn = $ast.Find({ param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'Hdg' }, $true)
$params = @($fn.Body.ParamBlock.Parameters | ForEach-Object { $_.Name.VariablePath.UserPath })
"run-time Hdg parameters: $($params -join ', ')"

$expected = 'Hdg "P" ("TEST HEADING TEXT")'
$bad = @($hdg | Where-Object { $_ -match '^Hdg "P\s+\S' })
if ($bad.Count) { "result: WRONG - options and heading in one string (expected the form $expected)"; exit 1 }
"result: OK"; exit 0
